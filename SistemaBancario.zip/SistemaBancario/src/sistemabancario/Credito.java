
package sistemabancario;

// Clase abstracta Credito
// Define una estructura base para los diferentes tipos de créditos
// Sirve como plantilla para los diferentes tipos de crédito y no puede ser instanciada directamente
abstract class Credito {
    
    protected double monto; // Monto del crédito
    protected int plazo; // Plazo en meses
    
    // Constructor de la clase Credito
    // Inicializa el monto y el plazo del crédito
    public Credito(double monto, int plazo) {
        this.monto = monto;
        this.plazo = plazo;
    }
    
    public abstract double calcularCuota();
    
}
