/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sistemabancario;

/**
 *
 * @author decker
 */
public class SistemaBancario {

    public static void main(String[] args) {
        
        CreditoPersonal cp = new CreditoPersonal(10000, 5, 12);
        System.out.println("Cuota Crédito Personal: " + cp.calcularCuota());
        
        CreditoEmpresarial ce = new CreditoEmpresarial(20000, 3000, 10);
        System.out.println("Cuota Crédito Empresarial: " + ce.calcularCuota());
        
        CreditoEspecial cs = new CreditoEspecial(15000, 15);
        System.out.println("Cuota Crédito Especial: " + cs.calcularCuota());
        
    }
    
}
