
package sistemabancario;

// Clase Banco para probar los créditos
// Se encarga de crear diferentes tipos de créditos y mostrar sus cuotas calculadas
class SistemaBancario {

    public static void main(String[] args) {
        
        // Crear un cliente           // Nombre _ Cedula _ email _ Telefono _ Direccion   
        Cliente cliente1 = new Cliente("Juan Pérez", "12345678", "juan@email.com", "3001234567", "Calle 123"); 
        
        // Método principal (punto de entrada del programa)
        // Se encarga de ejecutar el programa e imprimir los cálculos de las cuotas
        CreditoPersonal cp = new CreditoPersonal(95000000, 5, 240); // Monto _ interes _ plazo
        System.out.println("Cuota Crédito Personal: " + cp.calcularCuota());
        
        CreditoEmpresarial ce = new CreditoEmpresarial(20000, 3000, 10);
        System.out.println("Cuota Crédito Empresarial: " + ce.calcularCuota());
        
        CreditoEspecial cs = new CreditoEspecial(15000, 15);
        System.out.println("Cuota Crédito Especial: " + cs.calcularCuota());
        
    }
    
}
