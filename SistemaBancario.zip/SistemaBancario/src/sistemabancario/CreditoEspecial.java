/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemabancario;

// Clase CreditoEspecial (sin interés, hereda de Credito)
// Representa un crédito especial en el que no se aplica ningún interés, la cuota se obtiene dividiendo el monto entre el plazo
class CreditoEspecial extends Credito{
    
    // Constructor de CreditoEspecial
    // Recibe el monto y el plazo del crédito especial
    public CreditoEspecial(double monto, int plazo) {
        super(monto, plazo); // Llamada al constructor de la superclase 
    }
    
    // Implementación del método calcularCuota para Crédito Especial
    // Calcula la cuota mensual dividiendo el monto total entre el plazo
    // No incluye intereses
    // Retorna el valor de la cuota mensual
    @Override
    public double calcularCuota() {
        return monto / plazo; // Fórmula de cálculo de cuota sin interés
    }
}
