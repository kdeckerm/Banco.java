/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemabancario;

// Clase CreditoEmpresarial (hereda de Credito)
// Representa un crédito empresarial, donde el interés es un valor fijo negociado en lugar de un porcentaje
class CreditoEmpresarial extends Credito{
    
    private double valorInteres; // Valor fijo de interés negociado  
    
    // Constructor de CreditoEmpresarial
    // Recibe el monto, el valor de interés fijo y el plazo
    public CreditoEmpresarial(double monto, double valorInteres, int plazo) {
        super(monto, plazo); // Llamada al constructor de la superclase
        this.valorInteres = valorInteres;
    }
    
    // Implementación del método calcularCuota para Crédito Empresarial
    // Calcula la cuota mensual sumando el monto con el interés fijo y dividiendo por el plazo
    // Retorna el valor de la cuota mensual
    @Override
    public double calcularCuota() {
        return (monto + valorInteres) / plazo; // Fórmula de cálculo de cuota
    }
    
}

