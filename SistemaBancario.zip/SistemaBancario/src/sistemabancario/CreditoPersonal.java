/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemabancario;

// Clase CreditoPersonal (hereda de Credito)
// Representa un crédito personal, donde la cuota mensual se calcula aplicando un porcentaje de interés
class CreditoPersonal extends Credito {
    
    private double interes; // Porcentaje de interés
    
    // Constructor de CreditoPersonal
    // Recibe el monto, el interés y el plazo del crédito personal
    public CreditoPersonal(double monto, double interes, int plazo) {
        super(monto, plazo); // Llamada al constructor de la superclase
        this.interes = interes;
    }
    
    // Implementación del método calcularCuota para Crédito Personal
    // Calcula la cuota mensual basada en el monto del crédito, el interés y el plazo
    // Retorna el valor de la cuota mensual
    @Override
    public double calcularCuota() {
        return (monto + (monto * (interes / 100))) / plazo; // Fórmula de cálculo de cuota
    }
    
}
