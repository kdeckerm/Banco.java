
package sistemabancario;

// Clase Cliente que almacena información del cliente del banco
// Representa un cliente del banco con información personal asociada
class Cliente {
    
    private String nombre;
    private String documento;
    private String correo;
    private String telefono;
    private String direccion;
    
    // Constructor de Cliente
    // Recibe los datos personales del cliente y los almacena en atributos
    public Cliente(String nombre, String documento, String correo, String telefono, String direccion) {
        this.nombre = nombre;
        this.documento = documento;
        this.correo = correo;
        this.telefono = telefono;
        this.direccion = direccion;
    }
    
    // Métodos getter para acceder a los atributos
    public String getNombre() { return nombre; }
    public String getDocumento() { return documento; }
    public String getCorreo() { return correo; }
    public String getTelefono() { return telefono; }
    public String getDireccion() { return direccion; }

    // Método para mostrar la información del cliente
    public void mostrarInfo() {
        System.out.println("Cliente: " + nombre + " - Documento: " + documento);
    }
}
